-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 26, 2020 at 02:33 PM
-- Server version: 10.4.13-MariaDB
-- PHP Version: 7.4.7

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `based_playzone`
--
CREATE DATABASE IF NOT EXISTS `based_playzone` DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE `based_playzone`;

-- --------------------------------------------------------

--
-- Table structure for table `carrito_cliente`
--

CREATE TABLE `carrito_cliente` (
  `Car_ID` int(15) NOT NULL,
  `Producto` int(15) NOT NULL,
  `Car_TotalProducto` int(15) NOT NULL,
  `Car_TotalFinal` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `categoria`
--

CREATE TABLE `categoria` (
  `Cat_ID` int(15) NOT NULL,
  `Cat_Nombre` varchar(80) NOT NULL,
  `Cat_Imagenes` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `categoria`
--

INSERT INTO `categoria` (`Cat_ID`, `Cat_Nombre`, `Cat_Imagenes`) VALUES
(1, 'Computación', 'https://www.gforgames.com/wp-content/uploads/2020/09/gaming-equipment.jpg'),
(2, 'Gadgets', 'https://cdn.vox-cdn.com/thumbor/t-HVmKzTIuSPVuEF34rfQFN3lxI=/0x0:1400x913/1200x800/filters:focal(588x344:812x568)/cdn.vox-cdn.com/uploads/chorus_image/image/63704121/yoda.0.1543520280.0.jpg'),
(3, 'Consolas', 'https://www.telegraph.co.uk/content/dam/black-friday/2019/11/29/TELEMMGLPICT000200176524_trans_NvBQzQNjv4BqqVzuuqpFlyLIwiB6NTmJwRMWbYwzrg_3PLcMwCu9G8U.jpeg'),
(4, 'Ropa', 'https://www.picclickimg.com/00/s/MTQzOFgxNjAw/z/Z~EAAOSwgYBbU6Sx/$/Super-Mario-T-shirt-Bros-Red-Luigi-Green-_1.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `cliente`
--

CREATE TABLE `cliente` (
  `C_ID` int(15) NOT NULL,
  `C_Nombre` varchar(150) NOT NULL,
  `C_ApellidoP` varchar(150) NOT NULL,
  `C_ApellidoM` varchar(150) NOT NULL,
  `C_CorreoE` varchar(150) NOT NULL,
  `C_Password` varchar(150) NOT NULL,
  `C_Pais` varchar(35) NOT NULL,
  `C_CodigoPostal` varchar(20) NOT NULL,
  `C_Estado` varchar(20) NOT NULL,
  `C_Direccion` varchar(100) NOT NULL,
  `C_Genero` varchar(10) NOT NULL,
  `C_Tarjetas` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `cliente`
--

INSERT INTO `cliente` (`C_ID`, `C_Nombre`, `C_ApellidoP`, `C_ApellidoM`, `C_CorreoE`, `C_Password`, `C_Pais`, `C_CodigoPostal`, `C_Estado`, `C_Direccion`, `C_Genero`, `C_Tarjetas`) VALUES
(4, '', '', '', 'Oriol@gmail.com', '202cb962ac59075b964b07152d234b70', '', '', '', '', '', 0),
(6, '', '', '', 'Oriol100@gmail.com', '250cf8b51c773f3f8dc8b4be867a9a02', '', '', '', '', '', 0),
(7, '', '', '', 'javier@gmail.com', '698d51a19d8a121ce581499d7b701668', '', '', '', '', '', 0),
(8, '', '', '', 'manuel@hotmail.com', '550a141f12de6341fba65b0ad0433500', '', '', '', '', '', 0),
(9, '', '', '', 'Esdras@gmail.com', '15de21c670ae7c3f6f3f1f37029303c9', '', '', '', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `detalle_orden`
--

CREATE TABLE `detalle_orden` (
  `Orden_ID` int(15) NOT NULL,
  `Orden_Numero` int(150) NOT NULL,
  `Orden_Nombre` varchar(100) NOT NULL,
  `Orden_EnvioPaq` int(15) NOT NULL,
  `Orden_DetallePago` int(15) NOT NULL,
  `Orden_Total` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `favorito_cliente`
--

CREATE TABLE `favorito_cliente` (
  `Favorito_ID` int(15) NOT NULL,
  `Producto` int(15) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `marca_producto`
--

CREATE TABLE `marca_producto` (
  `Marca_ID` int(15) NOT NULL,
  `Marca_Nombre` varchar(150) NOT NULL,
  `Marca_Logo` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `paqueteria`
--

CREATE TABLE `paqueteria` (
  `Paq_ID` int(15) NOT NULL,
  `Paq_Nombre` varchar(50) NOT NULL,
  `Paq_Precio` float NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- --------------------------------------------------------

--
-- Table structure for table `producto`
--

CREATE TABLE `producto` (
  `Prod_ID` int(15) NOT NULL,
  `Prod_Nombre` varchar(150) NOT NULL,
  `Prod_Categoria` int(15) NOT NULL,
  `Prod_Precio` float NOT NULL,
  `Prod_Color` varchar(20) NOT NULL,
  `Prod_Disponible` varchar(10) NOT NULL,
  `Prod_Marca` varchar(35) NOT NULL,
  `Prod_Codigo` varchar(50) NOT NULL,
  `Prod_Condicion` varchar(20) NOT NULL,
  `Prod_Material` varchar(50) NOT NULL,
  `Prod_PesoKG` varchar(50) NOT NULL,
  `Prod_Imagenes` varchar(300) NOT NULL,
  `Prod_Desc` longtext NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `producto`
--

INSERT INTO `producto` (`Prod_ID`, `Prod_Nombre`, `Prod_Categoria`, `Prod_Precio`, `Prod_Color`, `Prod_Disponible`, `Prod_Marca`, `Prod_Codigo`, `Prod_Condicion`, `Prod_Material`, `Prod_PesoKG`, `Prod_Imagenes`, `Prod_Desc`) VALUES
(1, 'Corsair Headset', 1, 769, 'Negro', 'Si', 'Corsair', 'CA-9011206', 'Nuevo', 'Aluminio', '600gramos', 'https://www.ticotek.com/wp-content/uploads/2020/03/corsair-hs35.jpg', 'Auriculares de Diadema para Videojuegos con Sonido Envolvente 7.1'),
(2, 'Taza Pacman', 2, 369, 'Blanco', 'Si', 'Paladone', 'PP2525PMTX', 'Nuevo', 'Cerámica', '370g', 'https://www.ociostock.com/productos/imagenes/img_192517_d732f3bd411fffdf0760b1546cd3c92c_20.jpg', 'La taza de cerámica esculpida de Vandor de 40,64 ml está esculpida a medida y muy bien elaborada para que sea una pieza coleccionable. Está fabricado con cerámica de alta calidad y cuenta con un diseño de personajes atrevidos. Esta taza premium es ideal para el uso diario, exhibición o regalo, y se recomienda lavar a mano.'),
(3, 'Intel Core i9', 1, 17499, 'Negro', 'Si', 'Intel', 'B086MHSTVD', 'Nuevo', 'Silicio, aluminio, cobre, oro y otros metales.', '330g', 'https://i5.walmartimages.com/asr/c7ad0bee-5e53-44fb-993f-c715421e1f2c.f148fa9f56aa912133ceb1410bf56669.jpeg', 'Procesador de sobremesa desbloqueado Intel Core i9-10900K. Con la tecnología Intel Turbo Boost Max 3. Los procesadores de sobremesa Intel Core de 10ª generación desbloqueados están optimizados para jugadores entusiastas y creadores serios y ayudan a proporcionar un overclocking de alto rendimiento para una mayor mejora. '),
(4, 'Playstation 4 Pro', 3, 8799, 'Blanco', 'Si', 'Sony Computer Entertainment', 'B01LOP8EZC', 'Nuevo', 'Plastico, Aluminio', '3.49Kg', 'https://cdn.alzashop.com/ImgW.ashx?fd=f3&cd=MSX001n', 'Se considera que esta consola es la mejor dentro del mercado, dado que presenta una resolución de hasta 4K.\r\nVas a poder reproducir música, ver tus películas y series favoritas a través de las aplicaciones descargables.'),
(5, 'Logitech G502', 1, 899, 'Negro', 'Si', 'Logitech G', '910-005550', 'Nuevo', 'Platico, Aluminio', '371g', 'https://http2.mlstatic.com/D_NQ_NP_873417-MLA31022336343_062019-O.jpg', 'El Mouse inalámbrico Logitech G502 LIGHTSPEED para juegos no sólo elimina hábilmente el cable, mejora además el ya espectacular sensor y respalda este de alto desempeño con un paquete de Software de grandes prestaciones. Realmente el G502 volvió a lo grande. El mouse G502 es todo un icono que ha ocupado las primeras posiciones de las listas generación tras generación. Y es el mouse que eligen quienes juegan en serio. Ahora, el mouse G502 se une a las filas de los mouse inalámbricos para juegos más avanzados del mundo con el lanzamiento de G502 LIGHTSPEED. LIGHTSPEED es una tecnología ultrarrápida y confiable con desempeño probado en competencia por profesionales de eSports.'),
(6, 'Funko Pop Sonic', 2, 169, 'Azul', 'Si', 'Funko Pop', 'B0764G47JY', 'Nuevo', 'Plastico', '85g', 'https://resources.claroshop.com/medios-plazavip/mkt/5f88f605be29e_funko-pop-sonic-with-emerald-284-minpng.jpg', 'Figura coleccionable de la marca Funko, representa al personaje de la película o serie de la que se trata. Articulo de coleccionista.'),
(7, 'Playera Zelda', 4, 79, 'Cafe', 'Si', 'Nintendo Official', 'B06XGR4F4K', 'Nuevo', '100 % Algodón', '119g', 'https://www.serishirts.com/54602/zelda-de-hyrule-de-cerveza-antiguo-t-shirt.jpg', 'Este artículo está impreso con impresiones digitales a base de agua, que utilizan una solución a base de vinagre para garantizar la vibración y durabilidad. Este aroma es solo temporal y desaparecerá rápidamente.'),
(8, 'Teclado Razer', 1, 1769, 'Negro', 'Si', 'Razer USA', 'RZ03-02520200', 'Nuevo', 'Aluminio, Plastico', '861g', 'https://www.computershopping.com.ar/Images/Productos/RZ03-01222400-R3M1_Foto3.jpg', 'Teclado de juegos RGB multicolor Teclas retroiluminadas individualmente Diseño resistente a derrames.'),
(9, 'Mouse Pad RGB', 1, 299, 'Negro', 'Si', 'Dprofy', 'B088D2964V', 'Nuevo', 'Caucho', '218g', 'https://images-na.ssl-images-amazon.com/images/I/51bS1opMEOL._AC_SL1001_.jpg', 'Alfombrilla de mouse para juegos con iluminación RGB diseñada con base de goma antideslizante para mantener la posición fija, no importa lo duro que muevas los ratones. Comodidad de usar. Diseñado con material trenzado de fibra superfina, con una superficie microtexturizada y suave, navegación precisa.\r\nTamaño grande: 340 x 245 x 3 mm.'),
(10, 'Baby Yoda', 2, 499, 'Verde', 'Si', 'Mattel', 'GWD85', 'Nuevo', 'Poliestre', '100g', 'https://images-na.ssl-images-amazon.com/images/I/71EhXXbGs3L._AC_SL1500_.jpg', 'Descubre la ternura de la especie Yoda de 50 años con este adorable peluche de 28 centímetros. Puede parecer un bebé Yoda, pero esta criatura adorable se conoce como The Child. Inspirado en la serie de Disney+ The Mandalorian, este dulce peluche de Star Wars es una adición increíble a tu colección. El peluche de juguete tiene un cuerpo suave y cuenta con una base resistente, perfecto para abrazar o exhibir como un objeto de colección. El personaje usa su túnica como se ve en el programa. A los fanáticos de Star Wars les encantará asumir el papel de The Mandalorian Bounty Hunter y cuidar a The Child por su cuenta.'),
(11, 'Razer Kraken', 1, 869, 'Negro', 'Si', 'Razer USA', 'RZ04-02950100', 'Nuevo', 'Plastico', '229g', 'https://images-na.ssl-images-amazon.com/images/I/61dwuOuWXmL._AC_SL1440_.jpg', 'Tanto si estás compitiendo en un torneo intenso o descansando en casa, Kraken x Lite es un auricular dedicado a una calidad de sonido superior y una comodidad duradera para que puedas jugar al máximo todo el día. Disfruta de una claridad de sonido superior y graves profundos y potentes para un amplio paisaje sonoro. Desde sutiles pasos que se esconden detrás de ti hasta explosiones climáticas que te vuelan, cada detalle de sonido se escucha cuando juegas con el Razer Kraken x Lite.'),
(12, 'Gorra Zelda', 4, 269, 'Negro', 'Si', 'Nintendo Official', 'B00GSLQWPC', 'Nuevo', 'Poliestre 80%, Algodon20%', '112g', 'https://elektra.vteximg.com.br/arquivos/ids/378987-1000-1000/3020455.jpg?v=636492009790070000', 'Zelda is one of the first and best know franchises to start on the Nintendo gaming systems. Link is the main character in the world of Zelda. His task is often rescuing the Princess Zelda. The Triforce is a sacred golden relic left behind by the Golden Goddesses, Din, Nayru, and Farore, once they finished creating the realm, which came to be known as Hyrule. This hat features a snapback sizing. The front displays a large gold raised embroidered Triforce logo.');

-- --------------------------------------------------------

--
-- Table structure for table `tarjeta_pago`
--

CREATE TABLE `tarjeta_pago` (
  `Tarjeta_ID` int(15) NOT NULL,
  `Tarjeta_Tipo` varchar(30) NOT NULL,
  `Tarjeta_NombreBanco` varchar(50) NOT NULL,
  `Tarjeta_Numero` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `carrito_cliente`
--
ALTER TABLE `carrito_cliente`
  ADD PRIMARY KEY (`Car_ID`),
  ADD KEY `Producto` (`Producto`);

--
-- Indexes for table `categoria`
--
ALTER TABLE `categoria`
  ADD PRIMARY KEY (`Cat_ID`);

--
-- Indexes for table `cliente`
--
ALTER TABLE `cliente`
  ADD PRIMARY KEY (`C_ID`),
  ADD KEY `C_Tarjetas` (`C_Tarjetas`);

--
-- Indexes for table `detalle_orden`
--
ALTER TABLE `detalle_orden`
  ADD PRIMARY KEY (`Orden_ID`),
  ADD KEY `Orden_EnvioPaq` (`Orden_EnvioPaq`),
  ADD KEY `Orden_DetallePago` (`Orden_DetallePago`);

--
-- Indexes for table `favorito_cliente`
--
ALTER TABLE `favorito_cliente`
  ADD PRIMARY KEY (`Favorito_ID`),
  ADD KEY `Producto` (`Producto`);

--
-- Indexes for table `marca_producto`
--
ALTER TABLE `marca_producto`
  ADD PRIMARY KEY (`Marca_ID`);

--
-- Indexes for table `paqueteria`
--
ALTER TABLE `paqueteria`
  ADD PRIMARY KEY (`Paq_ID`);

--
-- Indexes for table `producto`
--
ALTER TABLE `producto`
  ADD PRIMARY KEY (`Prod_ID`),
  ADD KEY `Prod_Categoria` (`Prod_Categoria`);

--
-- Indexes for table `tarjeta_pago`
--
ALTER TABLE `tarjeta_pago`
  ADD PRIMARY KEY (`Tarjeta_ID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `carrito_cliente`
--
ALTER TABLE `carrito_cliente`
  MODIFY `Car_ID` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categoria`
--
ALTER TABLE `categoria`
  MODIFY `Cat_ID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `cliente`
--
ALTER TABLE `cliente`
  MODIFY `C_ID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `detalle_orden`
--
ALTER TABLE `detalle_orden`
  MODIFY `Orden_ID` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `favorito_cliente`
--
ALTER TABLE `favorito_cliente`
  MODIFY `Favorito_ID` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `marca_producto`
--
ALTER TABLE `marca_producto`
  MODIFY `Marca_ID` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `paqueteria`
--
ALTER TABLE `paqueteria`
  MODIFY `Paq_ID` int(15) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `producto`
--
ALTER TABLE `producto`
  MODIFY `Prod_ID` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tarjeta_pago`
--
ALTER TABLE `tarjeta_pago`
  MODIFY `Tarjeta_ID` int(15) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `carrito_cliente`
--
ALTER TABLE `carrito_cliente`
  ADD CONSTRAINT `carrito_cliente_ibfk_1` FOREIGN KEY (`Producto`) REFERENCES `producto` (`Prod_ID`) ON UPDATE CASCADE;

--
-- Constraints for table `detalle_orden`
--
ALTER TABLE `detalle_orden`
  ADD CONSTRAINT `detalle_orden_ibfk_1` FOREIGN KEY (`Orden_EnvioPaq`) REFERENCES `paqueteria` (`Paq_ID`) ON UPDATE CASCADE,
  ADD CONSTRAINT `detalle_orden_ibfk_2` FOREIGN KEY (`Orden_DetallePago`) REFERENCES `tarjeta_pago` (`Tarjeta_ID`) ON UPDATE CASCADE;

--
-- Constraints for table `favorito_cliente`
--
ALTER TABLE `favorito_cliente`
  ADD CONSTRAINT `favorito_cliente_ibfk_1` FOREIGN KEY (`Producto`) REFERENCES `producto` (`Prod_ID`) ON UPDATE CASCADE;

--
-- Constraints for table `producto`
--
ALTER TABLE `producto`
  ADD CONSTRAINT `producto_ibfk_3` FOREIGN KEY (`Prod_Categoria`) REFERENCES `categoria` (`Cat_ID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
